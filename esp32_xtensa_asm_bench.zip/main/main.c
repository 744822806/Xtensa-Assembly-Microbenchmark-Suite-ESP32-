#include <stdio.h>
#include <stdint.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

// ASM declarations
uint32_t bitmask_set_asm(uint32_t value, uint32_t bit);
uint32_t bitmask_clear_asm(uint32_t value, uint32_t bit);
uint32_t popcount_asm(uint32_t v);

static uint32_t bitmask_set_c(uint32_t value, uint32_t bit) {
    return value | (1u << bit);
}

static uint32_t bitmask_clear_c(uint32_t value, uint32_t bit) {
    return value & ~(1u << bit);
}

static uint32_t popcount_c(uint32_t v) {
    uint32_t c = 0;
    while (v) {
        c += v & 1u;
        v >>= 1;
    }
    return c;
}

static inline uint32_t get_ccount(void) {
    uint32_t ccount;
    __asm__ __volatile__("rsr.ccount %0" : "=a"(ccount));
    return ccount;
}

void app_main(void) {
    vTaskDelay(pdMS_TO_TICKS(500));
    printf("\nXtensa ASM microbench on ESP32\n");
}
